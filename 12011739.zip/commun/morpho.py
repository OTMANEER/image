import cv2
import numpy as np

def myerode(i, es):

    return cv2.erode(i, es)

def mydilate(i,es):
    return cv2.dilate(i,es)

def mygrad(i,es):
    return (mydilate(i,es) - myerode(i,es))

def myopen(i,es):
    return mydilate(myerode(i, es), es)

def myclose(i,es):
    return myerode(mydilate(i, es), es)

