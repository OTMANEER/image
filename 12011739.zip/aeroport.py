import sys

import cv2
import commun.strel as strel
import commun.morpho as morpho
import numpy as np
import commun.myutil as myutil

image = cv2.imread(str(sys.argv[1]))
cv2.imshow('Image',image)

min = np.ones(image.shape,image.dtype)*255

taille = int(sys.argv[2])
for angle in range(-90,90):
    el = strel.build('ligne',taille,angle)
    cl = morpho.myclose(image,el)
    min = np.minimum(min,cl)

s=int(sys.argv[3])
output = str(sys.argv[4])

#image_seuille = myutil.myseuil_interactif(min)

image_seuille = myutil.myseuil(min,s)
open_image = morpho.myopen(image_seuille,strel.build('carre',1))

open_image = open_image[:,:,0]
cv2.imshow('Ouverture',open_image)
cv2.waitKey(0)

gradient = morpho.mygrad(open_image,strel.build('diamant',1))

image[gradient>0] = [0,0,255]

cv2.imshow(output,image)
print('Image created successfully')
cv2.imwrite(output,open_image)
cv2.waitKey(0)

